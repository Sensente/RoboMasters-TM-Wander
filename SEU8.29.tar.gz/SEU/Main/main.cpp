#include"ImgProdCons.h"
#include<thread>

using namespace std;

bool rm::ImgProdCons::_quit_flag = false;

int main()
{
    rm::ImgProdCons imgProdCons;

    imgProdCons.init();   //摄像头参数、装甲板参数、颜色参数灯等初始化
                                         //test_sentry.cpp

    std::thread produceThread(&rm::ImgProdCons::produce, &imgProdCons);
    std::thread consumeThread(&rm::ImgProdCons::consume, &imgProdCons);
    std::thread senseThread(&rm::ImgProdCons::sense, &imgProdCons);

    produceThread.join();  // for(;;) 生产(摄像头读取)
    consumeThread.join();  // for(;;) 消费（装甲板识别主要循环）
    senseThread.join();    // for(;;)

    return 0;
}
