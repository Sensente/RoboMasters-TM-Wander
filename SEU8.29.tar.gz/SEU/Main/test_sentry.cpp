#include<unistd.h>
#include"iostream"
#include<opencv2/opencv.hpp>
#include<thread>
#include<list>

#include"ImgProdCons.h"
#include"./Armor/ArmorDetector.h"
#include"./Pose/AngleSolver.hpp"
#include "./Windmill/WindmillDetect.h"

using namespace std;
using namespace cv;

//#define DEBUG
//#define GET_VIDEO
#define DEBUG_DATE   //打印装甲板类型、坐标、云台角度等信息

namespace rm
{

void ImgProdCons::init()
{
    //prevent usb port from being blocked 防止usb端口被阻止
    init_signals();       //ImgProdCons.cpp


    //Initialize camera   //RMvideoCapture.cpp
    _videoCapturePtr->open(0,2); // 0 works fine for small panel , if you meet problem opening the camera, try change this
    _videoCapturePtr->setVideoFormat(1280, 720, true);
    _videoCapturePtr->setExposureTime(100);
    _videoCapturePtr->setFPS(60);
    _videoCapturePtr->startStream();
    _videoCapturePtr->info();

    //Initilize serial    //Serial.cpp
    _serialPtr->openPort();
    _serialPtr->setDebug(true);

    int self_color;

/* 串口通信检测
    while(_serialPtr->setup(self_color) != Serial::OJBK)
    {
        sleep(1);
    }
*/

    cout << "I am " << (self_color == rm::BLUE ? "blue" : "red") << "." << endl;


    //Initialize angle solver   //AngleSolver.cpp
    AngleSolverParam angleParam;
    angleParam.readFile(9);     //读取 angle_solver_params.xml 文件， 内含"枪与镜头距离参数"
    _solverPtr->init(angleParam);
    _solverPtr->setResolution(_videoCapturePtr->getResolution()); //设置摄像头参数 cameraMatrix
                                                                        //distCoeffs

    //Initialize armor detector //ArmorDetector.cpp
    ArmorParam armorParam;
    _armorDetectorPtr->init(armorParam);

    //函数未定义 注释 By David
    //_armorDetectorPtr->setEnemyColor(self_color == rm::BLUE ? rm::RED : rm::BLUE);
}

//void updateFeeling(list<double>& feeling, const double duration)
//{
//    for(auto it = feeling.begin(); it != feeling.end(); it++)
//    {
//        if(*it < 10)
//        {
//            feeling.erase(it);
//        }
//        else
//        {
//            *it *= exp(0.1*duration);
//        }
//    }
//}

void ImgProdCons::sense()
{
    //	chrono::time_point<chrono::steady_clock> lastTime;
    //	list<double> worrys0, worrys1, pains;
    //	double totalWorry0, totalWorry1, totalPain;
    //	const double TAU = 0.1;
    //	const double M = 10;
    //	int remainHp = 3000;

    /* Loop for sensing */
    for(;;)
    {
        FeedBackData feedBackData;

        /* TODO: Handel exceptions when socket suddenly being plugged out. */
        if(_serialPtr->tryFeedBack(feedBackData, chrono::milliseconds(20)) == Serial::OJBK)
        {
            //			const auto nowTime = chrono::high_resolution_clock::now();
            //			const auto duration = (static_cast<chrono::duration<double, std::milli>>(nowTime - lastTime)).count();

            //			/*	Update historic worrys and pain */
            //			updateFeeling(worrys0, duration);
            //			updateFeeling(worrys1, duration);
            //			updateFeeling(pains, duration);

            //TODO: add other states
            _task = feedBackData.task_mode;

            //			auto pain = remainHp - feedBackData.remain_hp;
            //			remainHp = feedBackData.remain_hp;
            //			if(feedBackData.shot_armor == 0)
            //			{
            //				worrys0.push_back(pain);
            //				pains.push_back(pain);
            //			}
            //			else if(feedBackData.shot_armor == 1)
            //			{
            //				worrys1.push_back(pain);
            //				pains.push_back(pain);
            //			}

            //			totalWorry0 = accumulate()


            //			lastTime = nowTime;
            this_thread::sleep_for(chrono::milliseconds(80));
        }
        else
        {
            this_thread::sleep_for(chrono::milliseconds(50));
        }
    }
}

void ImgProdCons::consume()
{
    /*
     * Variables for recording camera
     */
    VideoWriter writer;
    bool isRecording = false;
    time_t t;
    time(&t);

    const string fileName = "/home/nvidia/Robomaster/Robomaster2018/" + to_string(t) + ".avi";
    writer.open(fileName, CV_FOURCC('M', 'J', 'P', 'G'), 25, Size(1280, 720));


    /* Variables for serial communication*/ //串行通信变量
    ControlData controlData;

    /* Variables for angle solve module */  //角度求解模块变量
    int angleFlag;
    Vec2f targetAngle;

    /* Variables for armor detector modeule */ //装甲板识别模块变量
    int armorFlag;
    int armorType;
    std::vector<cv::Point2f> armorVertex;

    /* The main loop for armor detection */
    auto t1 = chrono::high_resolution_clock::now();
    Frame frame;
    for(;;)
    {
        if(_serialPtr->getErrorCode() == Serial::SYSTEM_ERROR || !_videoCapturePtr->isOpened())
        {
            this_thread::sleep_for(chrono::seconds(3));
        }


        // comment this part when bebugging without STM upper computer

        //        if(_task != Serial::AUTO_SHOOT)
        //        {
        //            cout << "waiting for command." << endl;
        //            continue;
        //        }

        if(!_buffer.getLatest(frame)) continue;

        //主要都装甲板识别程序
        _armorDetectorPtr->loadImg(frame.img);
        armorFlag = _armorDetectorPtr->detect(); //检测程序


        // armorFlag = 2 || armorFlag = 3 (检测到装甲板)执行以下程序
        if(armorFlag == ArmorDetector::ARMOR_LOCAL || armorFlag == ArmorDetector::ARMOR_GLOBAL)
        {
            //得到装甲板四点坐标
            armorVertex = _armorDetectorPtr->getArmorVertex();

#ifdef DEBUG_DATE
            cout << "ArmorVertex:" << endl << armorVertex << endl;  //打印装甲板四点坐标
#endif
            //得到装甲板类型
            armorType = _armorDetectorPtr->getArmorType();

#ifdef DEBUG_DATE
            cout << "ArmorType:" << armorType << endl; //打印装甲板类型
#endif

            _solverPtr->setTarget(armorVertex, armorType);

            //姿态解算
            angleFlag = _solverPtr->solve();

#ifdef DEBUG_DATE
            cout << "AngleFlage:" << angleFlag << endl << endl;  //打印角度解算类型
#endif
            //如果解算不出错，执行以下程序
            if(angleFlag != rm::AngleSolver::ANGLE_ERROR)
            {
                //函数未定义 注释 By David
                targetAngle = _solverPtr->getCompensateAngle();

                //控制数据
                controlData.frame_seq   = frame.seq;                        //控制信号发送

                //controlData.shoot_mode  = Serial::BURST_FIRE | Serial::HrIGH_SPEED;
                controlData.shoot_mode  = Serial::BURST_FIRE; //更改 By David

                controlData.pitch_dev   = targetAngle[1];                   //俯仰
                controlData.yaw_dev     = targetAngle[0];                   //偏航
                //                controlData.speed_on_rail = 0;

#ifdef DEBUG_DATE  //打印云台旋转角度
                cout << "Pitch:" << controlData.pitch_dev << endl;
                cout << "Yaw:" << controlData.yaw_dev << endl << endl;
#endif

                controlData.gimbal_mode = Serial::SERVO_MODE;
                if(_serialPtr->tryControl(controlData, chrono::milliseconds(3)) != Serial::OJBK)
                {
                    //cout<<"not sent"<<endl; 暂时注释 ****×××××
                }

                //cout << "Deviation: " << targetAngle << endl; //Deviation 偏差 ，下面还有一处
            }
        }

        else
        {
            if(_serialPtr->tryControl(controlData, chrono::milliseconds(3)) != Serial::OJBK)
            {
                //cout<<"not sent"<<endl; 暂时注释
            }

            controlData.gimbal_mode = Serial::PATROL_AROUND;
        }

        //cout << "Deviation: " << targetAngle << endl;


#ifdef DEBUG
        auto t2 = chrono::high_resolution_clock::now();
        cout << "Total period: " << (static_cast<chrono::duration<double, std::milli>>(t2 - t1)).count() << " ms" << endl;
        cout << endl;
        t1 = t2;
#endif

#ifdef GET_VIDEO
        if(isRecording)
        {
            writer << frame.img;
        }
        if(!writer.isOpened())
        {
            cout << "Capture failed." << endl;
            continue;
        }
        isRecording = true;
        cout << "Start capture. " + fileName +" created." << endl;
        if(waitKey(1) == 'q')
        {
            return;
        }
#endif

    }


}
}
