#include<opencv2/opencv.hpp>
#include"../General/General.h"
#include<opencv2/ml.hpp>

namespace rm
{

class Windmill
{


public:
    int WindmillDetector();

};

}

